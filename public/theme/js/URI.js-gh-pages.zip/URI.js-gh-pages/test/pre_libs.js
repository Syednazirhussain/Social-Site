/*global window */
// FIXME: v2.0.0 renamce non-camelCase properties to uppercase
/*jshint camelcase: false */
window.URI                = window.URI_pre_lib                = 'original URI, before loading URI.js library';
window.URITemplate        = window.URITemplate_pre_lib        = 'original URITemplate, before loading URI.js library';
window.IPv6               = window.IPv6_pre_lib               = 'original IPv6, before loading URI.js library';
window.SecondLevelDomains = window.SecondLevelDomains_pre_lib = 'original SecondLevelDomains, before loading URI.js library';
